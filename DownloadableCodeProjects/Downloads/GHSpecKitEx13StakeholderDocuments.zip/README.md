GitHub Spec Kit commands will use stakeholder documentation to help generate the constitution.md, spec.md, and plan.md files.
